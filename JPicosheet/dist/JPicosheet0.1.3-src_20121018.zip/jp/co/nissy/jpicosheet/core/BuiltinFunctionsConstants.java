/**
 * JPicosheet: Spreadsheet engine for Java Applications
 * Copyright (C) 2011 yusuke nishikawa
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */
package jp.co.nissy.jpicosheet.core;

public final class BuiltinFunctionsConstants {

	/**
	 * 組み込み関数の定義
	 */
	public static final String[][] BUILTIN_FUNCTIONS = {
		{"AVERAGE", "jp.co.nissy.jpicosheet.function.AVERAGE"},
		{"ABS", "jp.co.nissy.jpicosheet.function.ABS"},
		{"SUM", "jp.co.nissy.jpicosheet.function.SUM"},
		{"MOD", "jp.co.nissy.jpicosheet.function.MOD"},
		{"INT", "jp.co.nissy.jpicosheet.function.INT"},
		{"IF", "jp.co.nissy.jpicosheet.function.IF"},
		{"AND", "jp.co.nissy.jpicosheet.function.AND"},
		{"OR", "jp.co.nissy.jpicosheet.function.OR"},
		{"NOT", "jp.co.nissy.jpicosheet.function.NOT"},
	};


}
